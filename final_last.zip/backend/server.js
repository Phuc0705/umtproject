const express = require("express");
const sql = require("mssql");
const cors = require("cors");
const path = require("path");
const bcrypt = require("bcrypt");
const session = require("express-session");
const fs = require('fs');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session middleware
app.use(session({
  secret: 'luxury-car-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 24 hours
}));

// Phục vụ tài nguyên tĩnh từ wwwroot
app.use(express.static(path.join(__dirname, '..', 'wwwroot')));

const config = {
  server: "VOSTRO-14-3000\\SQLEXPRESS",
  database: "LuxuryCarDB",
  user: "umtuser",         // user bạn vừa tạo
  password: "umt12345", // password bạn vừa đặt
  options: {
    trustServerCertificate: true
  },
  pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
};

let poolPromise = null;
async function getPool() {
  if (!poolPromise) {
    poolPromise = sql.connect(config);
  }
  return poolPromise;
}

// API: Lấy tất cả xe
app.get("/api/cars", async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query("SELECT * FROM Cars ORDER BY Name");
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi kết nối CSDL" });
  }
});

// API: Tìm kiếm xe
app.get("/api/cars/search", async (req, res) => {
  try {
    const { query, brand, priceRange, type } = req.query;
    const pool = await getPool();
    let sqlQuery = `SELECT * FROM Cars WHERE 1=1`;
    if (query) {
      sqlQuery += ` AND (Name LIKE '%${query}%' OR Brand LIKE '%${query}%' OR Description LIKE '%${query}%')`;
    }
    if (brand && brand !== 'all') {
      sqlQuery += ` AND Brand = '${brand}'`;
    }
    if (type && type !== 'all') {
      sqlQuery += ` AND Type = '${type}'`;
    }
    if (priceRange && priceRange !== 'all') {
      switch(priceRange) {
        case 'under1b':
          sqlQuery += ` AND Price < 1000000000`;
          break;
        case '1b-3b':
          sqlQuery += ` AND Price >= 1000000000 AND Price <= 3000000000`;
          break;
        case '3b-5b':
          sqlQuery += ` AND Price > 3000000000 AND Price <= 5000000000`;
          break;
        case 'over5b':
          sqlQuery += ` AND Price > 5000000000`;
          break;
      }
    }
    const result = await pool.request().query(sqlQuery);
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi tìm kiếm" });
  }
});

// API: Lấy chi tiết xe theo ID
app.get("/api/cars/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const pool = await getPool();
    const result = await pool.request().query(`SELECT * FROM Cars WHERE ID = ${id}`);
    if (result.recordset.length > 0) {
      res.json(result.recordset[0]);
    } else {
      res.status(404).json({ error: "Không tìm thấy xe" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi lấy thông tin xe" });
  }
});

// Đăng ký người dùng (lưu vào file users.txt, mặc định role=user)
app.post('/api/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const pool = await getPool();
    // Kiểm tra username/email đã tồn tại
    const check = await pool.request().query`SELECT * FROM Users WHERE Username = ${username} OR Email = ${email}`;
    if (check.recordset.length > 0) {
      return res.status(400).json({ error: 'Tên đăng nhập hoặc email đã tồn tại' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    await pool.request().query`
      INSERT INTO Users (Username, Email, PasswordHash, Role)
      VALUES (${username}, ${email}, ${hashedPassword}, 'user')
    `;
    res.json({ message: 'Đăng ký thành công' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Lỗi đăng ký' });
  }
});

// Đăng nhập (kiểm tra trong file users.txt, lưu role vào session)
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const pool = await getPool();
    const userRes = await pool.request().query`SELECT * FROM Users WHERE Username = ${username}`;
    if (userRes.recordset.length === 0) {
      return res.status(401).json({ error: 'Tên đăng nhập hoặc mật khẩu không đúng' });
    }
    const user = userRes.recordset[0];
    const isValidPassword = await bcrypt.compare(password, user.PasswordHash);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Tên đăng nhập hoặc mật khẩu không đúng' });
    }
    req.session.userId = user.ID;
    req.session.username = user.Username;
    req.session.role = user.Role;
    res.json({ message: 'Đăng nhập thành công', username: user.Username, role: user.Role });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Lỗi đăng nhập' });
  }
});

// API: Đăng xuất
app.post("/api/logout", (req, res) => {
  req.session.destroy();
  res.json({ message: "Đăng xuất thành công" });
});

// API: Kiểm tra trạng thái đăng nhập
app.get("/api/auth/status", (req, res) => {
  if (req.session.userId) {
    res.json({ isLoggedIn: true, user: { id: req.session.userId, username: req.session.username, role: req.session.role } });
  } else {
    res.json({ isLoggedIn: false });
  }
});

// ================= GIỎ HÀNG (CART) =================
// Thêm xe vào giỏ hàng
app.post("/api/cart/add", async (req, res) => {
  try {
    const { carId, quantity } = req.body;
    const userId = req.session.userId;
    const pool = await getPool();
    const check = await pool.request().query`SELECT * FROM CartItems WHERE UserID = ${userId} AND CarID = ${carId}`;
    if (check.recordset.length > 0) {
      await pool.request().query`UPDATE CartItems SET Quantity = Quantity + ${quantity} WHERE UserID = ${userId} AND CarID = ${carId}`;
    } else {
      await pool.request().query`INSERT INTO CartItems (UserID, CarID, Quantity) VALUES (${userId}, ${carId}, ${quantity})`;
    }
    res.json({ message: "Đã thêm vào giỏ hàng" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi thêm vào giỏ hàng" });
  }
});

// Lấy giỏ hàng của user
app.get("/api/cart", async (req, res) => {
  try {
    const userId = req.session.userId;
    const pool = await getPool();
    const result = await pool.request().query`
      SELECT CartItems.ID, CartItems.Quantity, Cars.*
      FROM CartItems
      JOIN Cars ON CartItems.CarID = Cars.ID
      WHERE CartItems.UserID = ${userId}
    `;
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi lấy giỏ hàng" });
  }
});

// Xóa xe khỏi giỏ hàng
app.delete("/api/cart/remove", async (req, res) => {
  try {
    const { carId } = req.body;
    const userId = req.session.userId;
    const pool = await getPool();
    await pool.request().query`DELETE FROM CartItems WHERE UserID = ${userId} AND CarID = ${carId}`;
    res.json({ message: "Đã xóa khỏi giỏ hàng" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi xóa khỏi giỏ hàng" });
  }
});

// API: Tạo đơn hàng
app.post("/api/orders", async (req, res) => {
  try {
    const { shippingAddress, phone } = req.body;
    const userId = req.session.userId;
    const pool = await getPool();
    // Lấy các xe trong giỏ
    const cartResult = await pool.request().query`SELECT * FROM CartItems WHERE UserID = ${userId}`;
    const cartItems = cartResult.recordset;
    if (cartItems.length === 0) {
      return res.status(400).json({ error: 'Giỏ hàng trống!' });
    }
    // Tính tổng tiền
    let totalAmount = 0;
    for (const item of cartItems) {
      const carRes = await pool.request().query`SELECT Price FROM Cars WHERE ID = ${item.CarID}`;
      if (carRes.recordset.length > 0) {
        totalAmount += carRes.recordset[0].Price * item.Quantity;
      }
    }
    // Tạo đơn hàng
    const orderResult = await pool.request().query`
      INSERT INTO Orders (UserID, TotalAmount, ShippingAddress, Phone, Status, CreatedAt)
      OUTPUT INSERTED.ID
      VALUES (${userId}, ${totalAmount}, ${shippingAddress}, ${phone}, 'Pending', GETDATE())
    `;
    const orderId = orderResult.recordset[0].ID;
    // Thêm từng xe vào OrderItems
    for (const item of cartItems) {
      const carRes = await pool.request().query`SELECT Price FROM Cars WHERE ID = ${item.CarID}`;
      const price = carRes.recordset.length > 0 ? carRes.recordset[0].Price : 0;
      await pool.request().query`
        INSERT INTO OrderItems (OrderID, CarID, Quantity, Price, CreatedAt)
        VALUES (${orderId}, ${item.CarID}, ${item.Quantity}, ${price}, GETDATE())
      `;
    }
    // Xóa giỏ hàng
    await pool.request().query`DELETE FROM CartItems WHERE UserID = ${userId}`;
    res.json({ message: 'Đặt hàng thành công!', orderId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Lỗi đặt hàng' });
  }
});

// API: Lấy lịch sử đơn hàng
app.get("/api/orders", async (req, res) => {
  try {
    const userId = req.session.userId;
    const pool = await getPool();
    const result = await pool.request().query`
      SELECT o.*, oi.CarID, oi.Quantity, oi.Price, c.Name, c.ImageUrl
      FROM Orders o
      JOIN OrderItems oi ON o.ID = oi.OrderID
      JOIN Cars c ON oi.CarID = c.ID
      WHERE o.UserID = ${userId}
      ORDER BY o.CreatedAt DESC
    `;
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi lấy lịch sử đơn hàng" });
  }
});

// Đặt hàng từ giỏ hàng (Checkout)
app.post("/api/cart/checkout", async (req, res) => {
  try {
    const { shippingAddress, phone } = req.body;
    const userId = req.session.userId;
    const pool = await getPool();
    // Lấy các xe trong giỏ hàng
    const cartResult = await pool.request().query`SELECT * FROM CartItems WHERE UserID = ${userId}`;
    const cartItems = cartResult.recordset;
    if (cartItems.length === 0) {
      return res.status(400).json({ error: "Giỏ hàng trống!" });
    }
    // Tính tổng tiền
    let totalAmount = 0;
    for (const item of cartItems) {
      const carRes = await pool.request().query`SELECT Price FROM Cars WHERE ID = ${item.CarID}`;
      if (carRes.recordset.length > 0) {
        totalAmount += carRes.recordset[0].Price * item.Quantity;
      }
    }
    // Tạo đơn hàng
    const orderResult = await pool.request().query`
      INSERT INTO Orders (UserID, TotalAmount, ShippingAddress, Phone, Status, CreatedAt)
      OUTPUT INSERTED.ID
      VALUES (${userId}, ${totalAmount}, ${shippingAddress}, ${phone}, 'Pending', GETDATE())
    `;
    const orderId = orderResult.recordset[0].ID;
    // Thêm từng xe vào OrderItems
    for (const item of cartItems) {
      const carRes = await pool.request().query`SELECT Price FROM Cars WHERE ID = ${item.CarID}`;
      const price = carRes.recordset.length > 0 ? carRes.recordset[0].Price : 0;
      await pool.request().query`
        INSERT INTO OrderItems (OrderID, CarID, Quantity, Price, CreatedAt)
        VALUES (${orderId}, ${item.CarID}, ${item.Quantity}, ${price}, GETDATE())
      `;
    }
    // Xóa giỏ hàng
    await pool.request().query`DELETE FROM CartItems WHERE UserID = ${userId}`;
    res.json({ message: "Đặt hàng thành công!", orderId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi đặt hàng" });
  }
});

// Backward compatibility
app.get("/cars", async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query`SELECT * FROM Cars`;
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).send("Lỗi kết nối CSDL");
  }
});

// Middleware kiểm tra quyền admin
function requireAdmin(req, res, next) {
  if (!req.session.role || req.session.role !== 'admin') {
    return res.status(403).json({ error: 'Chỉ admin mới được phép thực hiện chức năng này!' });
  }
  next();
}

// API xóa xe (chỉ admin)
app.delete('/api/cars/:id', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const pool = await getPool();
    await pool.request().query`DELETE FROM Cars WHERE ID = ${id}`;
    res.json({ message: 'Đã xóa xe thành công' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Lỗi xóa xe' });
  }
});

// API cập nhật xe (chỉ admin)
app.put('/api/cars/:id', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { Name, Brand, Type, Price, Horsepower, Fuel, Origin, Description, ImageUrl } = req.body;
    const pool = await getPool();
    await pool.request().query`
      UPDATE Cars SET
        Name = ${Name},
        Brand = ${Brand},
        Type = ${Type},
        Price = ${Price},
        Horsepower = ${Horsepower},
        Fuel = ${Fuel},
        Origin = ${Origin},
        Description = ${Description},
        ImageUrl = ${ImageUrl},
        UpdatedAt = GETDATE()
      WHERE ID = ${id}
    `;
    res.json({ message: 'Đã cập nhật xe thành công' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Lỗi cập nhật xe' });
  }
});

// Route mặc định chuyển về trang xe đang bán
app.get('/', (req, res) => res.redirect('/vehicles.html'));

app.listen(3000, () => console.log("🚀 Server chạy tại http://localhost:3000"));
